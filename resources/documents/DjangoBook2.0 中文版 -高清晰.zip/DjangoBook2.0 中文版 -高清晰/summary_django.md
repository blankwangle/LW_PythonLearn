## 表单学习

### win上删除一个非空的目录
rd /s 文件名
### 增加Python字典元素：两种方法
```
第一种  
dict1['a']=1 

第二种：setdefault方法  
dict1.setdefault('b',2)  
2  
dict1  
{'a': 1, 'b': 2} 
```
### python循环遍历字典元素
```
#coding:utf-8

mydict = {'1':'one', '2':'two'}
#第一种方法，使用items获取key和value的值
for key, value in mydict.items():
     print key , ':' , value


第二种方法，获取key的值，然后访问value的值
for key in mydict.keys():
     print key,':',mydict[key]


第三种方法，和第二种是一样的
for key in mydict:
    print key,':',mydict[key]
```

### django在模板中遍历输出字典的键和值(key,value)
main.html
```
<html>
    <title>
        request参数的测试
    </title>
    <body>
    I am here
    {% for key,value in urlDir.items %}
        <li>
            {{key}}:{{value}}
        </li>
    {%endfor%}
    </body>
</html>
```
view.py
```
#coding:utf-8
from django.shortcuts import render_to_response
from django.http import HttpResponse

# Create your views here.

def show(request):
    urlDir = {}
    urlDir['request.path:'] = request.path#除域名外的请求路径  ，以正斜杠开头
    print request.path
    urlDir['request.get_host:'] = request.get_host#主机名或者常说的域名
    print request.get_host
    urlDir['request.get_full_path:'] = request.get_full_path#请求路径，可以包含查询字符
    print request.get_full_path
    return render_to_response('main.html',locals())
```
结果
![dict_html](./dict_html.png)
### request.META
request.META是一个python的字典，包含了一次HTTP请求的head信息，比如用户的ip地址和用户Agent，Header信息的完整列表取决于用户所发送的header信息和服务器端设置的header信息
```
HTTP_REFERER，进站前链接网页，如果有的话。 （请注意，它是REFERRER的笔误。）
HTTP_USER_AGENT，用户浏览器的user-agent字符串，如果有的话。 例如：
"Mozilla/5.0 (X11; U; Linux i686; fr‐FR; rv:1.8.1.17) Gecko/20080829 Firefox/2.0.0.17" .
REMOTE_ADDR 客户端IP，如："12.345.67.89" 。(如果申请是经过代理服务器的话，那么它可能是以逗号分
割的多个IP地址，如："12.345.67.89,23.456.78.90" 。)
```
一个好的获取字典值的方法，也是处理不存在键值的方法
```
def dispalay(request):
	ua = request.MATE.get('HTTP_USER_AGENT','UNKNOW')
	return  HttpRequest("Your browser is %s" % ua)
```
### 写url切记的事情
在写url的时候一定不要在路径前面加 **/**,这样会导致路径找不到的
```
urlpatterns = [
    url(r'^admin/', admin.site.urls),#正确
    url(r'^$',login),#正确
    url(r'^show/$',login),#正确
	url(r'^/show/$',login),#错误，不能添加/

]
```
### post和get的使用
```
def login(request):
    if request.method == 'GET':
        return render_to_response('login.html')

    elif  request.method == 'POST':
        print '\n\n--------------',request.POST,'=====',request.POST.values(),'\n\n'
        if request.POST['username'] == '' or request.POST['password'] == '':
        #
        #应该去除故意的空格。
        #
        #if request.POST['username'].strip() == '' or request.POST['password'].strip() == '':
             return HttpResponse("Please enter account and password!")
        return render_to_response('display.html',request.POST)
```
### python中的local variable 'myform' referenced before assignment错误的原因
这是一个很坑的问题，出现这个问题的原因主要有两种，一种是局部变量不能被应用，另一种是自己的函数名或者模块名是一个已经存在的。
### 在url中正则表达式上加括号的原因
我们会在想要捕捉的文本的位置参数上加上小括号，在更高级的用法中，我们可以用表达式组类捕获url，将其作为关键字传递给视图
### 无命名组的URLconf和命名组的区别
```
urlpatterns = patterns('',
	(r'^articles/(\d{4})/$', views.year_archive),
	(r'^articles/(\d{4})/(\d{2})/$', views.month_archive),
)
--------------------------------------------------
urlpatterns = patterns('',
	(r'^articles/(?P<year>\d{4})/$', views.year_archive),
	(r'^articles/(?P<year>\d{4})/(?P<month>\d{2})/$', views.month_archive),
)
```
例如，如果不带命名组，请求 /articles/2006/03/ 将会等同于这样的函数调用：
month_archive(request, '2006', '03')
而带命名组，同样的请求就会变成这样的函数调用：
month_archive(request, year='2006', month='03')

### 使用命名组的好处
使用命名组可以让URLconf更加清晰，减少搞混参数次序的bug，你还可以对函数参数重新排序。
当然，命名组的代价就是失去了简洁性： 一些开发者觉得命名组的语法丑陋和显得冗余。 命名组的另一个好处
就是可读性强
### 匹配分组算法
```
需要注意的是如果在URLconf中使用命名组，那么命名组和非命名组是不能同时存在于同一个URLconf的模式
中的。 如果你这样做，Django不会抛出任何错误，但你可能会发现你的URL并没有像你预想的那样匹配正确。
具体地，以下是URLconf解释器有关正则表达式中命名组和 非命名组所遵循的算法:
如果有任何命名的组，Django会忽略非命名组而直接使用命名组。
否则，Django会把所有非命名组以位置参数的形式传递。
在以上的两种情况，Django同时会以关键字参数的方式传递一些额外参数。 更具体的信息可参考下一
节
```
### 传递额外的参数到视图函数中
具体的例子
```
urlpatterns = patterns('',
	(r'^foo/$', views.foobar_view, {'template_name': 'template1.html'}),
	(r'^bar/$', views.foobar_view, {'template_name': 'template2.html'}),
)
# views.py
from django.shortcuts import render_to_response
from mysite.models import MyModel
def foobar_view(request, template_name):
	m_list = MyModel.objects.filter(is_new=True)
	return render_to_response(template_name, {'m_list': m_list})
```

### 观察下面的例子
```
def object_list(request, model):
	obj_list = model.objects.all()
	template_name = 'mysite/%s_list.html' % model.__name__.lower()
	return render_to_response(template_name, {'object_list': obj_list})
```
1. 我们可以通过参数model参数直接传递了模型类，额外的urlconf参数的字典是可以传递任何类型的对象，而不仅仅是字符串
2. 使用model.__name__.lower()来决定模板的名字，每个python的类都有一个__name__属性返回类名，这特性在当直到我们运行的时候才知道对象类型的这种情况下很有作用，
### 捕获值和额外参数之间的优先级，额外的优先
当冲突出现的时候，额外的urlconf参数的优先级优于捕获值，也就是说当urlconf捕获到一个命名的一个命名组变量和一个额外urlconf参数包含的变量同名时，额外的urlconf参数会被使用

```
urlpatterns = patterns('',
	(r'^mydata/(?P<id>\d+)/$', views.my_view, {'id': 3}),
)
```
### 什么是命名组，什么是额外参数
> (r'^articles/(\d{4})/$', views.year_archive),
这是一个无命名组
> (r'^articles/(?P<year>\d{4})/$', views.year_archive)
这是一个命名组参数
> (r'^foo/$', views.foobar_view, {'template_name': 'template1.html'}),
这是一个额外的参数	

### 使用视图缺省参数
def page(request, num='1'):
### 从URL中捕获文本
每个被捕获的参数将被作为纯python字符串来发送的，而不管正则表达式中的格式
```
(r'^articles/(?P<year>\d{4})/$', views.year_archive)
```

这个URL尽管是匹配的整数，但是参数year是被作为字符串传到views.year_archive,而不是整型，他们都是unicode

### 额外的URLconf和include协同工作
```
相似的，你可以传递额外的URLconf选项到 include() , 就像你可以通过字典传递额外的URLconf选项到普通的
视图。 当你这样做的时候，被包含URLconf的 每一 行都会收到那些额外的参数。
比如，下面的两个URLconf在功能上是相等的。
第一个：
# urls.py
from django.conf.urls.defaults import *
urlpatterns = patterns('',
(r'^blog/', include('inner'), {'blogid': 3}),
)
# inner.py
from django.conf.urls.defaults import *
urlpatterns = patterns('',
(r'^archive/$', 'mysite.views.archive'),
(r'^about/$', 'mysite.views.about'),
(r'^rss/$', 'mysite.views.rss'),
)
第二个
# urls.py
from django.conf.urls.defaults import *
urlpatterns = patterns('',
(r'^blog/', include('inner')),
)
# inner.py
from django.conf.urls.defaults import *
urlpatterns = patterns('',
(r'^archive/$', 'mysite.views.archive', {'blogid': 3}),
(r'^about/$', 'mysite.views.about', {'blogid': 3}),
(r'^rss/$', 'mysite.views.rss', {'blogid': 3}),
)
```
自己解释：如果使用了include包含了一个url，那么在这个include包含的url中传递一个额外的参数，那么被包含的url都会接收到这个参数
文章解释：这个例子和前面关于被捕获的参数一样（在上一节就解释过这一点），额外的选项将 总是 被传递到被包含的
URLconf中的 每一 行，不管那一行对应的视图是否确实作为有效参数接收这些选项，因此，这个技术只有在你
确实需要那个被传递的额外参数的时候才显得有用。 因为这个原因，这种技术仅当你确信在涉及到的接受到额
外你给出的选项的每个URLconf时有用的才奏效
### 模板的渲染
模板的渲染是通过context获取值来替换模板中变量并执行所有的模板标签
### 解释
```
'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
```

**这个选项是一个可调用函数的元组，其中的每个函数使用了和上下文我们的def custom_proc(request):
"A context processor that provides 'app', 'user' and 'ip_address'."
return {
'app': 'My app',
'user': request.user,
'ip_address': request.META['REMOTE_ADDR']
} 说的简单点就是返回了一个字典      它是以request队形作为参数，返回一个会被合并传给context的字典：接收一个requst对象作为参数，返回一个包含了将被合并到context中的项的字典**
> 每个处理器将会按照顺序应用，也就是活如果你在第一个处理器中想contxt添加了一个变量，而第二个处理器添加了同样名字的变量，那么第二个将会覆盖第一个

### django.core.context_processors.auth
如果包含了这个处理器，那么每个RequestContext将包含这些变量：
user：一个django.contrib.auth.models.User实例。描述了当前登录用户
message:一个当前登录用户的消息列表，在后台，对每一个请求，这个变量都调用
request.user.get_and_delete_messages() 方法。 这个方法收集用户的消息然后把它们从数据库中删除。
perms django.core.context_processors.PermWrapper 的一个实例，包含了当前登录用户有哪些权限。
### django.core.context_processors.debug

这个处理器把调试信息发送到模板层，如果TEMP_CONTEXT_PROCESSORS包含这个处理器，每一个RequestContext将包含这些变量
debug ：你设置的 DEBUG 的值（ True 或 False ）。你可以在模板里面用这个变量测试是否处在debug模
式下。
sql_queries ：包含类似于 {‘sql’: …, ‘time’:  的字典的一个列表， 记录了这个请求期间的每个
SQL查询以及查询所耗费的时间。 这个列表是按照请求顺序进行排列的。

由于调试信息比较敏感，所以这个context处理器只有当同时满足下面的条件才有效：
1. DEBUG参数设置为true
2. 请求的ip应该包含在INSTERNAL_IPS的设置里面

### html的自动转义的处理
从模板生成html的时候，总是有一个风险--变量包含了会影响结果html的字符。
注意：用户提交的数据是不能被信任的
解决办法：你可以使用django的自动转义，在django默认使用的情况下这种行为是开启的。如果你正在使用django模板系统，那么你是被保护的。
这里的转义的意思是，当输入的是html标识的时候它会被认为是普通的字符，而不会当做html的一部分
### 可以通过include标签作用到其他标签。
### autoescape标签有两个参数on和off，可以阻止一部分自动转义，对另一部分自动转义。
```
Auto‐escaping is on by default. Hello {{ name }}
	{% autoescape off %}
	This will not be auto‐escaped: {{ data }}.
	Nor this: {{ other_data }}
	{% autoescape on %}
	Auto‐escaping applies again: {{ name }}
	{% endautoescape %}
	{% endautoescape %}
```
### 由于在base模板中自动转意被关闭,所以在child模板中自动转意也会关闭.
### 模板加载的内幕
#### django有两种方法加载模板
* django.template.loader.get_template(template_name) ： get_template 根据给定的模板名称返回一个
已编译的模板（一个 Template 对象）。 如果模板不存在，就触发 TemplateDoesNotExist 的异常。
* django.template.loader.select_template(template_name_list) ： select_template 很像
get_template ，不过它是以模板名称的列表作为参数的。 它会返回列表中存在的第一个模板。 如果模板
都不存在，将会触发TemplateDoesNotExist异常。
### 创建一个模板库
#### 不管是写自定义标签还是过滤器，第一件是要做的的事实创建模板库
##### 创建一个模板库分两步走
1. 第一，决定模板库应该放在哪个Django应用下。 如果你通过 manage.py startapp 创建了一个应用，你可
以把它放在那里，或者你可以为模板库单独创建一个应用。 我们更推荐使用后者，因为你的filter可能在后
来的工程中有用。无论你采用何种方式，请确保把你的应用添加到 INSTALLED_APPS 中。 我们稍后会解释这一点。
2. 第二，在适当的Django应用包里创建一个 templatetags 目录。 这个目录应当和 models.py 、 views.py 等
处于同一层次。 例如：
books/
__init__.py
models.py
templatetags/
views.py
在 templatetags 中创建两个空文件： 一个 __init__.py （告诉Python这是 一个包含了Python代码的包）
和一个用来存放你自定义的标签/过滤器定义的文件。 第二个文件的名字稍后将用来加载标签。 例如，如
1
2010-5-5 第九章：模版高级进阶
djangobook.py3k.cn/2.0/chapter09/ 9/19
果你的自定义标签/过滤器在一个叫作 poll_extras.py 的文件中，你需要在模板中写入如下内容：
{% load poll_extras %}
{% load %} 标签检查 INSTALLED_APPS 中的设置，仅允许加载已安装的Django应用程序中的模板库。 这是
一个安全特性；它可以让你在一台电脑上部署很多的模板库的代码，而又不用把它们暴露给每一个Django
安装。